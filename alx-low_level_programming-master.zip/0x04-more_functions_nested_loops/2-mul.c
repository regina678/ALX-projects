#include "main.h"

/**
 * mul - multiplies two integer numbers
 * @a: first integer
 * @b: second integer
 * Return: sum
 */

int mul(int a, int b)
{
	int sum = a * b;

	return (sum);
}
