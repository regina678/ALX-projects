Intial readme for task 0x05-pointers_arrays_strings
