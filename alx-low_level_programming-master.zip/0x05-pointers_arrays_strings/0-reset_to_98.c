#include "main.h"

/**
 * reset_to_98 - updates the value it points
 * @n: pointer of the direction at the variable n
 *
 * Return: 0
 */

void reset_to_98(int *n)
{
	*n = 98;
}
