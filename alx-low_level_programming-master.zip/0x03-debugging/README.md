0x03. C - Debugging
main file is a test for a postitive or negative()
