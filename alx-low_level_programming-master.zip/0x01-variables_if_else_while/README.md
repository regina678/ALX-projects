This an assignment ALX low level programmiing language.
0-positive or negative.c Prints is positive, is zero or is negative when a randomly generated number is any of these cases
1-last digit.c Prints the last digit of a randomly generated number
program that prints the alphabet in lowercase, followed by a new line.
program that prints the alphabet in lowercase, and then in uppercase, followed by a new line.
program that prints the alphabet in lowercase, followed by a new line.
program that prints all single digit numbers of base 10 starting from 0, followed by a new line.
program that prints the lowercase alphabet in reverse, followed by a new line.
program that prints all the numbers of base 16 in lowercase, followed by a new line
program that prints all possible combinations of single-digit numbers
