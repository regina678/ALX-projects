#ifndef LIKEMACRO_H
#define LIKEMACRO_H

#define SUM(x, y) (x + y)

#endif
