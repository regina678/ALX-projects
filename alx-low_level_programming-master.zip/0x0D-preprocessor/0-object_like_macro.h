#ifndef MACRO_H
#define MACRO_H

#define SIZE 1024

#endif
