#ifndef MACRO_H
#define MACRO_H

#define PI 3.14159265359

#endif
