0x06. C - More pointers, arrays and strings
