script that runs a C file through the preprocessor and save the result into another file.
